(function($){
    $(document).ready(function() {
        $('p:empty').remove();
    });
})(jQuery);