News Plugin
===========

The News Plugin creates a new Custom Post type (based on the core `post`) and two custom taxonomies (News Categories and News Tags) in `lib/post_type.php`. Its main purpose is to separate News items from blog posts.

Templates
---------

Two templates are used by the plugin to display the post type archive / taxonomy archive page and the single news item page. These templates are in the `templates` directory of the plugin, and their use can be overridden by the theme or a child theme which includes templates named `archive-news.php` or `single-news.php`.

Templates for taxonomy-based archives can also be overrideden by the theme or a child theme using one of the following file names:

 * `taxonomy-news_category-{term slug}.php`
 * `taxonomy-news_category.php`
 * `taxonomy-news_tag-{term slug}.php`
 * `taxonomy-news_tag.php`


Plugin Settings
---------------

Settings for the plugin are managed using ACF option fields, all defined in `lib/acf.php`. The fields currenty available are:

**Page Title**
Adds a custom title to the news archive page. If left blank the title of the page will be "News".

**Page introduction**
Adds an introduction (wysiwyg) to the top of the news archive pages.

**Hide Search**
Allows users to hide the search box on the news archive page

**Related news**
Allows users to include related news items (by `news_category`) on single news pages.

Admin Settings
--------------

There are some admin-related hooks and filters in `lib/admin.php` which add the custom taxonomies as filters on the news listing page of the wordpress dashboard.