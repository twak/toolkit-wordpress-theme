Events Plugin
=============

The Events plugin creates a Custom Post Type for Events, and has some configured ACF fields for event information (start date, end date, etc.). It also has its own Settings page where you can configure the title and lead content for the post type archive page, and the display of the calendar.

Templates
---------

Three templates are used by the plugin to display the post type archive, taxonomy archive page and the single item page. These templates are in the `templates` directory of the plugin, and their use can be overridden by a theme or a child theme which includes templates named `archive-events.php`, `single-events.php` and `taxonomy-events.php`.

Templates for taxonomy-based archives can also be overridden by the theme or a child theme using one of the following file names:

 * `taxonomy-events_category-{term slug}.php`
 * `taxonomy-events_category.php`
 * `taxonomy-events_tag-{term slug}.php`
 * `taxonomy-events_tag.php`


Plugin Settings
---------------

Settings for the plugin are managed using ACF option fields, all defined in `lib/acf.php`. The fields currenty available are:

**Page Title**
Adds a custom title to the events archive page. If left blank the title of the page will be "Events".

**Page introduction**
Adds an introduction (wysiwyg) to the top of the events archive pages.

**Hide Search**
Allows users to hide the search box on the events archive page

**Related events**
Allows users to include related events items (by `event_category`) on single event pages.

Admin Settings
--------------

There are some admin-related hooks and filters in `lib/admin.php` which add the custom taxonomies as filters on the events listing page of the wordpress dashboard. They also add the event date, and facilitate sorting and filtering by event date.