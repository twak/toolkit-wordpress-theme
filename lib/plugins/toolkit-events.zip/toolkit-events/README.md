Events Plugin
=============

This plugin creates a custom post type for events, and adds custom fields to it to facilitate ordering of events by event date. It also creates a taxonomy for events.