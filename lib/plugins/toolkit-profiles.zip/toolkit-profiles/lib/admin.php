<?php
/**
 * Toolkit Profiles Plugin admin area modifications
 * adds filters / columns / sorting on Profiles admin listing page
 */

if ( ! class_exists( 'tk_profiles_admin' ) ) {
    class tk_profiles_admin
    {
        public static function register()
        {
            /**
             * adds custom columns to profiles table in admin
             */
            add_action( 'manage_edit-profiles_columns', array(__CLASS__, 'add_profiles_columns') );
            add_action( 'manage_profiles_posts_custom_column', array(__CLASS__, 'show_profiles_columns'), 10, 2 );

            /**
             * adds filter to profiles table in admin for profile_category taxonomy
             */
            add_action( 'restrict_manage_posts', array( __CLASS__, 'restrict_profiles_by_category' ) );

            /**
             * Creates custom slug settings
             */
            add_action( 'admin_init', array( __CLASS__, 'add_permalink_section' ) );
        }

        /**
         * adds columns to the profiles listing table
         * hooks into 'manage_edit-profiles_columns'
         * @param array $posts_columns
         * @return array $new_posts_columns
         */
        public static function add_profiles_columns( $posts_columns )
        {
            $posts_columns['profile_category'] = 'Categories';
            return $posts_columns;
        }

        /**
         * shows the taxonomy column of the manage profiles table
         * hooks into 'manage_profiles_posts_custom_column'
         * @param $column_id
         * @param $post_id
         */
        public static function show_profiles_columns( $column_id, $post_id )
        {
            global $post;
            switch ($column_id) {
                case "profile_category":
                    $et = get_the_terms($post_id, $column_id);
                    $url = "edit.php?post_status=all&post_type=profiles&$column_id=";               
                    if (is_array($et)) {
                        $term_links = array();
                        foreach($et as $key => $term) {
                            $term_links[] = '<a href="' . $url . $term->slug . '">' . $term->name . '</a>';
                        }
                        echo implode(' | ', $term_links);
                    }
                    break;
            }
        }

        /**
         * resticts listed profiles by category if a filter has been applied
         */
        public static function restrict_profiles_by_category()
        {
            global $typenow;
            global $wp_query;
            if ($typenow == 'profiles') {
                $selected = isset( $wp_query->query['profile_category'] ) ? $wp_query->query['profile_category']: false;
                wp_dropdown_categories( array(
                    'show_option_all' => 'Show All Profile categories',
                    'taxonomy'        => 'profile_category',
                    'name'            => 'profile_category',
                    'value_field'     => 'slug',
                    'selected'        => $selected,
                    'show_count'      => true
                ) );
            }
        }

        /**
         * adds a section to Settings->Permalinks to enable users to 
         * change the profiles and profile category slugs (base)
         * uses Settings API
         */
        public static function add_permalink_section()
        {
            /* save settings */
            if ( isset( $_POST['tk_profiles_base'] ) ) {
                update_option( 
                    'tk_profiles_base', 
                    sanitize_title_with_dashes( $_POST['tk_profiles_base'] )
                );
                update_option( 
                    'tk_profile_categories_base', 
                    sanitize_title_with_dashes( $_POST['tk_profile_categories_base'] ) 
                );
            }

            /* add section for profiles */
            add_settings_section(
                'tk_profiles_permalinks',
                'Profile URLs',
                '__return_empty_string',
                'permalink'
            );

            /* Add settings fields to the permalink page */
            add_settings_field(
                'tk_profiles_base', 
                'Profiles URL Base',
                array(__CLASS__, 'add_slug_settings_callback'),
                'permalink',
                'tk_profiles_permalinks',
                array( 'field_name' => 'tk_profiles_base' )
            );
            add_settings_field(
                'tk_profile_categories_base', 
                'Profile Categories Base',
                array(__CLASS__, 'add_slug_settings_callback'),
                'permalink',
                'tk_profiles_permalinks',
                array( 'field_name' => 'tk_profile_categories_base' )
            );
        }
        
        /**
         * generic callback for slug settings input field
         */
        public static function add_slug_settings_callback( $options )
        {
            $field = $options["field_name"];
            $value = get_option( $field );
            printf('<input type="text" value="%s" name="%s" id="%s" class="regular-text" />', esc_attr( $value ), $field, $field );
        }
    }
    tk_profiles_admin::register();
}