<?php
/**
 * using profiles as authors
 */

if ( ! class_exists( 'tk_profiles_as_post_authors' ) ) {

    class tk_profiles_as_post_authors
    {
        /* register all hooks with wordpress API */
        public static function register()
        {
            /* register post author custom field */
            add_action( 'acf/init', array( __CLASS__, 'register_post_authors' ) );

            /* add author data to posts */
            add_action( 'tk_content_before', array( __CLASS__, 'add_author_credit' ) );
            add_filter( 'tk_content_after', array( __CLASS__, 'add_author_bio' ) );

            /* change author column for posts */
            add_action( 'manage_edit-post_columns', array(__CLASS__, 'add_profiles_column') );
            add_action( 'manage_post_posts_custom_column', array(__CLASS__, 'show_profiles_column'), 10, 2 );

            /* adds a list of author posts on profile page */
            add_action( 'tk_profiles_after_content', array(__CLASS__, 'add_author_posts'), 10, 2 );
        }

        /**
         * register post author custom field
         */
        public static function register_post_authors()
        {
            if( function_exists('acf_add_local_field_group') ) {

                acf_add_local_field_group(array (
                    'key' => 'group_5805dae7babfd',
                    'title' => 'Post Author',
                    'fields' => array (
                        array (
                            'key' => 'field_5805daf2d9cda',
                            'label' => 'Select one or more authors',
                            'name' => 'post_authors',
                            'type' => 'post_object',
                            'instructions' => '',
                            'required' => 1,
                            'conditional_logic' => 0,
                            'wrapper' => array (
                                'width' => '',
                                'class' => '',
                                'id' => '',
                            ),
                            'post_type' => array (
                                0 => 'profiles',
                            ),
                            'taxonomy' => array (
                            ),
                            'allow_null' => 0,
                            'multiple' => 1,
                            'return_format' => 'object',
                            'ui' => 1,
                        ),
                    ),
                    'location' => array (
                        array (
                            array (
                                'param' => 'post_type',
                                'operator' => '==',
                                'value' => 'post',
                            ),
                        ),
                    ),
                    'menu_order' => 0,
                    'position' => 'side',
                    'style' => 'default',
                    'label_placement' => 'top',
                    'instruction_placement' => 'label',
                    'hide_on_screen' => array (
                        0 => 'author',
                    ),
                    'active' => 1,
                    'description' => ''
                ));
            }
        }

        /**
         * adds author credits above the content
         */
        public static function add_author_credit()
        {
            if ( get_post_type( get_the_ID() ) === 'post' ) {
                return $content;
            }
            $authors = get_field('post_authors');
            if ( is_array( $authors ) && count( $authors) ) {
                $out .= '<div class="author-credit-above">';
                if ( count( $authors ) === 1 ) {
                    //External/Internal link flag
                    $url = ( get_field('tk_profiles_external_link_flag', $authors[0]->ID) ) ? get_field('tk_profiles_external_link', $authors[0]->ID): get_permalink($authors[0]->ID);
                    $out .= sprintf('<p>Written by <a href="%s" title="Profile of %s">%s</a></p>', $url, esc_attr( $authors[0]->post_title ), $authors[0]->post_title );
                } else {
                    $author_html = array();
                    foreach( $authors as $author ) {
                        $url = ( get_field('tk_profiles_external_link_flag', $author->ID) ) ? get_field('tk_profiles_external_link', $author->ID): get_permalink($author->ID);
                        $author_html[] = sprintf('<a href="%s" title="Profile of %s">%s</a>', $url, esc_attr( $author->post_title ), $author->post_title ); 
                    }
                    $last = array_pop($author_html);
                    $out .=sprintf('<p>Written by %s and %s</p>', implode(', ', $author_html), $last );
                }
                $out .= '</div>';
            }
            print($out);
        }

        /**
         * adds author bios after the content
         */
        public static function add_author_bio()
        {
            $out = '';
            if ( get_post_type( get_the_ID() ) === 'post' ) {
                $authors = get_field('post_authors');
                if ( is_array( $authors ) && count( $authors) ) {
                    $out .= '<div class="container-row "><div class="wrapper-md wrapper-pd-md equalize">';
                    if ( count( $authors ) === 1 ) {
                        //External/Internal link flag
                        $url = ( get_field('tk_profiles_external_link_flag', $authors[0]->ID) ) ? get_field('tk_profiles_external_link', $authors[0]->ID): get_permalink($authors[0]->ID);
                        $out .= '<h3 class="h2-lg heading-underline">Author</h3><div class="clearfix">';
                        $out .= self::get_author_card($authors[0]->ID, $authors[0]->post_title, $authors[0]->post_content, $url);
                    } else {
                        $out .= '<h3 class="h2-lg heading-underline">Authors</h3><div class="clearfix">';
                        foreach( $authors as $author ) {
                            $url = ( get_field('tk_profiles_external_link_flag', $author->ID) ) ? get_field('tk_profiles_external_link', $author->ID): get_permalink($author->ID);
                            $out .= self::get_author_card($author->ID, $author->post_title, $author->post_content, $url);
                        }
                    }
                    $out .= '</div></div></div>';
                }
            }
            print($out);
        }

        /**
         * gets author details in a card
         * @see add_author_details()
         */
        private static function get_author_card( $id, $name, $bio = '', $url )
        {
            $out = '<div><div class="card-flat skin-box-module">';
            if ( has_post_thumbnail( $id ) ) {
                $out .= sprintf('<div class="card-img card-img-1-3"><div class="rs-img rs-img-2-1" style="background-image: url(\'%s\');"><a href="%s" title="%s">&nbsp;</a></div></div>', get_the_post_thumbnail_url( $id ), $url, esc_attr( $name ) );
            }
            $out .= '<div class="card-content equalize-inner" style="height: 120px;"><span class="equalizer-inner" style="display:block;">';
            $out .= sprintf('<h3 class="heading-link-alt"><a href="%s" title="Profile of %s">%s</a></h3>', $url, esc_attr( $name ), $name );
            $out .= sprintf('<div class="note">%s</div>', wpautop( wptexturize( $bio ) ) );
            $out.= sprintf('<a class="more" href="%s">View profile</a>', $url );
            $out .= '</span></div></div></div>';
            return $out;
        }

        /**
         * Adds a list of posts by the author to the profile page
         */
        public static function add_author_posts( $profile_id, $profile_title )
        {
            /**
             * gets the posts using a meta query
             * the post_authors acf field saves profile IDs in a serializeed array, so
             * we need to query using the profile ID in double quotes and a LIKE comparison
             */
            $args = array(
                'numberposts' => -1,
                'post_type' => 'post',
                'meta_query' => array(
                    array(
                        'key' => 'post_authors',
                        'value' => '"' . $profile_id . '"',
                        'compare' => 'LIKE'
                    )
                )
            );
            $author_posts_query = new WP_Query( $args );
            if( $author_posts_query->have_posts() ) {
                printf('<h3>Posts by %s</h3><ul>', $profile_title);
                while ( $author_posts_query->have_posts() ) : $author_posts_query->the_post();
                    $authors = get_field( 'post_authors' );
                    if ( count($authors) === 1 ) {
                        printf('<li><a href="%s">%s</a></li>', get_permalink(), get_the_title() );
                    } else {
                        $author_html = array();
                        foreach( $authors as $author ) {
                            if ( $author->ID !== $profile_id ) {
                                $url = ( get_field('tk_profiles_external_link_flag', $author->ID) ) ? get_field('tk_profiles_external_link', $author->ID): get_permalink($author->ID);
                                $author_html[] = sprintf('<a href="%s" title="Profile of %s">%s</a>', $url, esc_attr( $author->post_title ), $author->post_title );
                            }
                        }
                        if ( count($author_html) === 1 ) {
                            $additional_authors = sprintf(' (with %s)', $author_html[0] );
                        } else {
                            $last = array_pop($author_html);
                            $additional_authors = sprintf('(with %s and %s</p>', implode(', ', $author_html), $last );
                        }
                        printf('<li><a href="%s">%s</a>%s</li>', get_permalink(), get_the_title(), $additional_authors );
                    }
                endwhile;
            }
            wp_reset_query();
       }

        /**
         * adds a new columns to posts table for authors (set via profiles)
         */
        public static function add_profiles_column( $posts_columns )
        {
            $posts_columns['profile_author'] = 'Author(s)';
            unset($posts_columns['author']);
            return $posts_columns;
        }

        /**
         * shows the authors assigned to a post from the profiles section rather than the post_author
         */
        public static function show_profiles_column( $column_id, $post_id )
        {
            if ( 'profile_author' === $column_id ) {
                $authors = get_field('post_authors', $post_id);
                if ( is_array( $authors ) && count( $authors) ) {
                    $author_html = array();
                    foreach( $authors as $author ) {
                        $url = admin_url('post.php?action=edit&post=' . $author->ID);
                        $author_html[] = sprintf('<a href="%s" title="Edit profile for %s">%s</a>', $url, esc_attr( $author->post_title ), $author->post_title );
                    }
                    return implode( ", ", $author_html );
                } else {
                    print('-');
                }
            }
        }
    }
    tk_profiles_as_post_authors::register();
}