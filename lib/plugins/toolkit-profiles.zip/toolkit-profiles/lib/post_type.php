<?php
/**
 * Custom post type and taxonomy for Toolkit Profiles plugin
 */

if ( ! class_exists( 'tk_profiles_post_type' ) ) {

    class tk_profiles_post_type
    {
        public static function register()
        {
            /**
             * Add profiles Post Type taxonomy
             * added with priority LESS THAN post type registration
             * to ensure the rewrite slug is not overwritten
             */
            add_action( 'init', array( __CLASS__, 'create_taxonomy' ), 9 );

            /**
             * Add profiles Custom Post Type
             * added with priority GREATER THAN taxonomy registration
             * to ensure the rewrite slug is not overwritten
             */
            add_action('init', array( __CLASS__, 'create_post_type' ), 10 );
            
            /**
             * Add in profiles templates (single and archive)
             */
            add_filter('single_template', array( __CLASS__, 'single_template' ) );
            add_filter('archive_template', array( __CLASS__, 'archive_template' ) );
        }

        /**
         * creates a profiles taxonomy
         */
        public static function create_taxonomy()
        {
            $profileCatSlugSetting = get_option( 'tk_profile_categories_base' );
            $profileCatSlug = $profileCatSlugSetting ? $profileCatSlugSetting : 'profile_type';
            
            register_taxonomy('profile_category', array('profiles'), array(
                'hierarchical' => true,
                'labels' => array(
                    'name' => 'Profile Categories',
                    'singular_name' => 'Profile Category',
                    'search_items' => 'Search Profile Categories',
                    'all_items' => 'All Profile Categories',
                    'parent_item' => 'Parent Profile Category',
                    'parent_item_colon' => 'Parent Profile Category:',
                    'edit_item' => 'Edit Profile Category', 
                    'update_item' => 'Update Profile Category',
                    'add_new_item' => 'Add New Profile Category',
                    'new_item_name' => 'New Profile Category',
                    'menu_name' => 'Profile Categories'
                ),
                'show_ui' => true,
                'query_var' => true,
                'rewrite' => array(
                    'slug' => $profileCatSlug,
                    'with_front' => false
                )
            ) );
        }

        /**
         * creates the profiles post type
         */
        public static function create_post_type()
        {
            $profileSlugSetting = get_option( 'tk_profiles_base' );
            $profilesSlug = $profileSlugSetting ? $profileSlugSetting : 'profiles';

            register_post_type('profiles', // Register Custom Post Type
                array(
                'labels' => array(
                    'name' => 'Profiles', 
                    'singular_name' => 'Profile',
                    'add_new' => 'Add New',
                    'add_new_item' => 'Add New Profile',
                    'edit' => 'Edit',
                    'edit_item' => 'Edit Profile',
                    'new_item' => 'New Profile',
                    'view' => 'View Profile',
                    'view_item' => 'View Profile',
                    'search_items' => 'Search Profiles',
                    'not_found' => 'No Profile found',
                    'not_found_in_trash' => 'No Profile found in Trash', 
                ),
                'public' => true,
                'hierarchical' => true,
                'has_archive' => true,
                'supports' => array(
                    'title',
                    'editor',
                    'thumbnail'
                ),
                'rewrite' => array(
                    'slug' => $profilesSlug,
                    'with_front' => false
                ),
                'menu_icon' => 'dashicons-admin-users',
                'can_export' => true
            ));
        }
        /**
         * ensures template is used from plugin for single event pages
         */
        public static function single_template($single_template)
        {
            global $post;
            if ($post->post_type === 'profiles' ) {
                $theme_path = get_stylesheet_directory() . '/single-profiles.php';
                $template_path = get_template_directory() . '/single-profiles.php';
                $plugin_path = plugin_dir_path( __DIR__ ) . 'templates/single-profiles.php';
                if ( file_exists( $theme_path ) ) {
                    return $theme_path;
                } elseif ( file_exists( $template_path ) ) {
                    return $template_path;
                } elseif ( file_exists( $plugin_path ) ) {
                    return $plugin_path;
                }
            }
            return $single_template;
        }

        /**
         * ensures template is used from plugin for event archives
         */
        public static function archive_template($archive_template)
        {
            global $wp_query;
            if ( is_post_type_archive('profiles') || is_tax('profile_category') ) {
                
                /**
                 * checks for overrides in template and theme for taxonomy archives
                 */
                if ( is_tax( 'profile_category' ) ) {
                    /**
                     * first check for templates which are specific to terms
                     * taxonomy-{taxonomy}-{term}.php
                     */
                    $qo = get_queried_object();
                    $tax = 'profile_category';

                    if ( $qo->slug ) {
                        $theme_path_term = get_stylesheet_directory() . '/taxonomy-' . $tax . '-' . $qo->slug . '.php';
                        $template_path_term = get_template_directory() . '/taxonomy-' . $tax . '-' . $qo->slug . '.php';
                        if (file_exists($theme_path_term)) {
                            return $theme_path_term;
                        } elseif (file_exists($template_path_term)) {
                            return $template_path_term;
                        }
                    }

                    /**
                     * now check for templates which are specific to the taxonomy
                     * taxonomy-{taxonomy}.php
                     */
                    $theme_path_tax = get_stylesheet_directory() . '/taxonomy-' . $tax . '.php';
                    $template_path_tax = get_template_directory() . '/taxonomy-' . $tax . '.php';
                    $plugin_path_tax = plugin_dir_path( __DIR__ ) . 'templates/taxonomy-' . $tax . '.php';
                    if (file_exists($theme_path_tax)) {
                        return $theme_path_tax;
                    } elseif (file_exists($template_path_tax)) {
                        return $template_path_tax;
                    } elseif (file_exists($plugin_path_tax)) {
                        return $plugin_path_tax;
                    }
                }
                /**
                 * checks for overrides in template and theme for post type archive
                 */
                $theme_path = get_stylesheet_directory() . '/archive-profiles.php';
                $template_path = get_template_directory() . '/archive-profiles.php';
                $plugin_path = plugin_dir_path( __DIR__ ) . 'templates/archive-profiles.php';
                if (file_exists($theme_path)) {
                    return $theme_path;
                } elseif (file_exists($template_path)) {
                    return $template_path;
                } elseif (file_exists($plugin_path)) {
                    return $plugin_path;
                }
            }
            return $archive_template;
        }
    }
    tk_profiles_post_type::register();
}