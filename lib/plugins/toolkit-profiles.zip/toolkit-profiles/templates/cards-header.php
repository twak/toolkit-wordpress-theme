<?php
/**
 * outputs the start of the cards container
 */
?>
<div class="row clearfix equalize">
