<?php
/**
 * outputs the end of the cards container
 */
?>
</div>