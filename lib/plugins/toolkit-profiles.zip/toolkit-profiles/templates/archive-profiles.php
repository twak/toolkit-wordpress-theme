<?php 

//ACF Profile page settings

//Custom title
$profiles_page_title = (get_field('tk_profiles_page_settings_title', 'option') ?: 'Profiles');

//Intro (Lead text)
$intro = get_field('tk_profiles_page_settings_introduction', 'option');

// Display logic
$display = (get_field('tk_profile_display', 'option') ?: 'all');

//Card layout order
$order = (get_field('tk_profiles_page_settings_template_categories', 'option') ?: 'alphabetical');

?>

<?php get_header(); ?>

<div class="wrapper-pd-xs">
    <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>">Home</a></li>
        <li><?= $profiles_page_title ?></li>
    </ul>
</div>

<div class="wrapper-md wrapper-pd">

    <h1 class="heading-underline"><?= $profiles_page_title ?></h1>

    <?php if($intro): ?>    
    <div class="wrapper-md">
        <?php echo $intro; ?>
    </div>
    <?php endif; ?>

<?php

//
if ( $display === 'by_cat' ) {
    include(dirname(__FILE__) . '/loop-by-cat.php' );
} else {
    include(dirname(__FILE__) . '/loop-all.php' );
}
?>

</div>

<?php get_footer(); ?>
