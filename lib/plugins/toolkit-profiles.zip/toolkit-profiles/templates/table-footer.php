<?php
/**
 * outputs the table footer
 */
?>
    </tbody>
</table>