<?php 
// term display settings
$term = get_queried_object();

// get breadcrumbs for nested categories
$crumbs = '';
if ( $term->parent !== 0 ) {
    $ancestors = array_reverse( get_ancestors( $term->term_id, 'profile_category', 'taxonomy' ) );
    foreach( $ancestors as $ancestor_id ) {
        $a = get_term($ancestor_id, 'profile_category');
        $crumbs .= sprintf('<li><a href="%s">%s</a></li>', get_term_link($ancestor_id), $a->name);
    }
}

// main profiles archive page URL
$profiles_url = get_post_type_archive_link( 'profiles' );

// ACF Profile page setting - Custom title
$profiles_title = get_field('tk_profiles_page_settings_title', 'option');
if ( ! $profiles_title ) {
    $profiles_title = 'Profiles';
}

// intro is category description
$intro = ( $term->description !== '' ) ? $term->description: '';

?>

<?php get_header(); ?>

<div class="wrapper-pd-xs">
    <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>">Home</a></li>
        <li><a href="<?php echo $profiles_url; ?>"><?php echo $profiles_title; ?></a></li>
        <?php echo $crumbs; ?>
        <li><?php echo $term->name; ?></li>
    </ul>
</div>

<div class="wrapper-md wrapper-pd">

    <h1 class="heading-underline"><?php echo $profiles_title; ?>: <?php echo $term->name; ?></h1>    

    <?php if($intro): ?>    
    <div class="wrapper-md">
        <?php echo $intro; ?>
    </div>
    <?php endif; ?>

<?php
include(dirname(__FILE__) . '/loop-all.php' );
?>

</div>

<?php get_footer(); ?>
