<?php
/**
 * Plugin Name: Toolkit Profiles
 * Plugin URI: https://bitbucket.org/university-of-leeds/toolkit-profiles
 * Bitbucket Plugin URI: https://bitbucket.org/university-of-leeds/toolkit-profiles
 * Description: This plugin adds toolkit profiles.
 * Version: 1.0.7
 * Author: Web Team
 * Author URI: https://bitbucket.org/university-of-leeds
 * License: GPL2
 */

if ( ! class_exists( 'tk_profiles' ) ) {

    class tk_profiles
    {
        /* plugin version */
        public static $version = "1.0.7";

        /* register all hooks with wordpress API */
        public static function register()
        {

            /**
             * upgrade from previous version
             */
            add_action( 'init', array( __CLASS__, 'upgrade' ), 11 );

            /**
             * load plugin functions from lib
             */
            include_once dirname(__FILE__) . '/lib/post_type.php';
            include_once dirname(__FILE__) . '/lib/acf.php';
            include_once dirname(__FILE__) . '/lib/admin.php';
            if ( get_option( 'options_tk_profiles_as_authors' ) ) {
                include_once dirname(__FILE__) . '/lib/profiles-as-authors.php';
            }

	        /**
	         * Enqueues the Profiles CSS
	         */
	        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_styles' ) );

            /**
             * flushes rewrite rules when plugin is activated
             */
            //register_activation_hook( __FILE__, array( __CLASS__, 'flush_rules' ) );
        }

        /**
         * upgrades the plugin from a previous version
         */
        public static function upgrade()
        {
            $current_version = get_option('tk_profiles_plugin_version');
            if ($current_version != self::$version) {
                switch ($current_version) {
                    case false:
                        /* updates sites which used built in categories */

                        // get all profiles
                        $profiles = get_posts( array(
                            'post_type' => 'profiles',
                            'numberposts' => -1
                        ) );

                        // re-add support for built in category taxonomy
                        register_taxonomy_for_object_type( 'category', 'profiles' );

                        // store used categories in here
                        $used_cats = array();

                        // store mapping in here
                        $cats_map = array();

                        // collect terms from existing profiles
                        foreach ( $profiles as $profile ) {
                            $terms = get_the_category( $profile->ID );
                            if ( $terms ) {
                                $cats_map[$profile->ID] = array();
                                foreach ($terms as $term ) {
                                    if ( ! isset( $used_cats[$term->term_id] ) ) {
                                        $used_cats[$term->term_id] = $term;
                                    }
                                    $cats_map[$profile->ID][] = $term->term_id;
                                }
                            }
                        }

                        // add the new categories
                        if ( count( $used_cats ) ) {
                            foreach( $used_cats as $cat_id => $term ) {
                                // set up new terms
                                $result = wp_insert_term(
                                    $term->name,
                                    'profile_category'
                                );
                             }
                        }

                        // add terms to profiles
                        if ( count( $cats_map ) ) {
                            foreach( $cats_map as $profile_id => $terms ) {
                                if ( count( $terms ) ) {
                                    wp_set_object_terms( $profile_id, $terms, 'profile_category', false );
                                }
                                // delete relationship between profile and category taxonomy
                                wp_delete_object_term_relationships( $profile_id, 'category' );
                            }
                        }
                        break;
                }
                /* update the version option */
                update_option('tk_profiles_plugin_version', self::$version);
            }
        }

	    /**
	     * Enqueues the Profiles CSS
	     */
	    public static function enqueue_styles() {
		    wp_enqueue_style(
			    'toolkit-profiles-css',
			    plugins_url( 'css/toolkit-profiles.css', __FILE__ ),
			    '',
			    '0.1'
		    );
	    }

        /**
         * Flush rewrite rules when creating new post type
         * @see https://paulund.co.uk/flush-permalinks-custom-post-type
         */
        function flush_rules()
        {
            self::create_taxonomy();
            self::create_post_type();
            flush_rewrite_rules();
        }
    }
    tk_profiles::register();
}