Profiles plugin
===============

The Profiles plugin creates a Custom Post Type for user profiles (based on the core `page` type), and a custom taxonomy (hierarchical) for Profiles. Each profile page contains a set of fields which are used to display contact information, a picture, and other details.

Templates
---------

Two main templates are used by the plugin to display the post type archive / taxonomy archive page and the single profile page. These templates use other templates in the `templates` directory of the plugin depending on which layout and features have been chosen for display.

Profile Settings
----------------

The profiles archive page lists profiles in a number of different ways, and uses two different layouts. How this page behaves is configured in `Profiles->Profile settings` in the wordpress dashboard.

**Page Title**
Adds a custom title to the profiles archive page. This is used at the top of the page and in the breadcrumb navigation. If left blank the title of the page will be "Profiles"

**Page Introduction**
Adds an introduction (wysiwyg) to the top of the profile archive pages.

**Profile Display**
Profiles can be displayed on a single page, or on different pages (each corresponding to a profile category).

**Profile Display by category**
If you choose to display profiles on different pages, you need to add rules for each of the categories you want to display. A rule consists of a category selection, a preferred layout (cards or table) and preferred order (menu order or alphabetical by surname)

**Layout**
When displaying all profiles on a single page, choose the most appropriate layout for the number of profiles you need to display (and the availability of good imagery for them). Card layouts show the profile picture above the Name and Job description fields. Table layouts can show multiple fields.

**Profiles order**
Profiles can be displayed in alphabetical order (by surname) or in "menu" order - this is the order in which they appear in the wordpress dashboard in the Profiles section.

**Fields to include in table view**
This allows you to configure which fields are used in the table view.

**Related Profiles**
This will include links to profiles within the same category at the bottom of a single profile page.

Admin Settings
--------------

There are some admin-related hooks and filters which add the custom taxonomy as a filter on the profiles listing page of the wordpress dashboard.