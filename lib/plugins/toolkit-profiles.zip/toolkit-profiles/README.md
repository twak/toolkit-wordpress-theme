Profiles Plugin
===============

The Profiles plugin creates a Custom Post Type for user profiles (based on the core `page` type), and a custom taxonomy (hierarchical, like categories) for Profiles. Each profile page contains a set of fields which are used on the profile pages to display contact information, a picture, and other details.

Profile Settings
----------------

The profiles archive page lists profiles in a number of different ways, and uses two different layouts. How this page behaves is configured in `Profiles->Profile settings` in the wordpress dashboard.

**Page Title** - the main title for the profiles archive page. This is used at the top of the page and in the breadcrumb navigation
**Page Introduction** - this text will appear under the page title.
**Profile Display** - profiles can be displayed on a single page, or on different pages (each corresponding to a profile category).
**Profile Display by category** - if you choose to display profiles on different pages, you need to add rules for each of the categories you want to display. A rule consists of a category selection, a preferred layout (cards or table) and preferred order (menu order or alphabetical by surname)
**Layout** - when displaying all profiles on a single page, choose the most appropriate layout for the number of profiles you need to display (and the availability of good imagery for them). Card layouts show the profile picture above the Job description field. Table layouts can show multiple fields.
**Profiles order** - profiles can be displayed in alphabetical order (by surname) or in "menu" order - this is the order in which they appear in the wordpress dashboard in the Profiles section.
**Fields to include in table view** - this allows you to configure which fields are used in the table view.
**Related Profiles** - this will include links to profiles within the same category at the bottom of a single profile page.